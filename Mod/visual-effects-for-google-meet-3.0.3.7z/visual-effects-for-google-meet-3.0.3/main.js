// if (location.href.includes("visual-effects")) {
// } else {
// }
